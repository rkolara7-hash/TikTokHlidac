package cz.radek.tiktokhlidac

import android.app.Notification
import android.os.Bundle
import android.os.Parcelable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class TikTokNotificationListener : NotificationListenerService() {

    private val allowedPackages = setOf(
        "com.zhiliaoapp.musically",
        "com.zhiliaoapp.musically.go"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in allowedPackages) return

        val notification = sbn.notification ?: return
        val extracted = extractNotification(notification)
        val title = extracted.first
        val body = extracted.second

        if (title.isBlank() && body.isBlank()) return

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val onlyLikelyMessages = prefs.getBoolean("onlyLikelyMessages", true)
        if (onlyLikelyMessages && !looksLikeMessage(notification, title, body)) return

        val db = DatabaseHelper(applicationContext)
        val matchingText = "$title $body"
        val accountId = db.matchAccount(matchingText)
        val key = sbn.key ?: "${sbn.packageName}:${sbn.id}:${sbn.postTime}:$title:$body"
        db.insertMessage(accountId, title, body, sbn.postTime, key)

        sendBroadcast(android.content.Intent(ACTION_NEW_MESSAGE).setPackage(packageName))
    }

    /**
     * TikTok může poslat text zprávy různými způsoby podle verze Androidu a aplikace.
     * Proto zkoušíme běžný text, rozbalený text, více řádků i MessagingStyle.
     */
    private fun extractNotification(notification: Notification): Pair<String, String> {
        val extras = notification.extras ?: Bundle.EMPTY
        val title = firstNonBlank(
            extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
        )

        val pieces = linkedSetOf<String>()

        addIfUseful(pieces, extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString())
        addIfUseful(pieces, extras.getCharSequence(Notification.EXTRA_TEXT)?.toString())
        addIfUseful(pieces, extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString())
        addIfUseful(pieces, extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString())

        extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach {
            addIfUseful(pieces, it?.toString())
        }

        @Suppress("DEPRECATION")
        extras.getCharSequenceArray(Notification.EXTRA_REMOTE_INPUT_HISTORY)?.forEach {
            addIfUseful(pieces, it?.toString())
        }

        val messageBundles = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        messageBundles?.forEach { parcelable ->
            val bundle = parcelable as? Bundle ?: return@forEach
            val text = bundle.getCharSequence("text")?.toString().orEmpty()
            val sender = extractSender(bundle)
            val line = if (sender.isNotBlank() && text.isNotBlank()) "$sender: $text" else text
            addIfUseful(pieces, line)
        }

        val body = pieces
            .filter { it.isNotBlank() && !sameText(it, title) }
            .joinToString("\n")
            .trim()

        return title.orEmpty().trim() to body
    }

    private fun extractSender(bundle: Bundle): String {
        val senderText = bundle.getCharSequence("sender")?.toString().orEmpty()
        if (senderText.isNotBlank()) return senderText

        // Android 9+ MessagingStyle ukládá odesílatele jako Person v tomto Bundle.
        return try {
            val person = bundle.getParcelable<Parcelable>("sender_person")
            if (person != null) {
                val getName = person.javaClass.methods.firstOrNull { it.name == "getName" && it.parameterCount == 0 }
                getName?.invoke(person)?.toString().orEmpty()
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun addIfUseful(target: MutableSet<String>, value: String?) {
        val cleaned = value.orEmpty().trim()
        if (cleaned.isNotBlank()) target += cleaned
    }

    private fun firstNonBlank(vararg values: String?): String {
        return values.firstOrNull { !it.isNullOrBlank() }.orEmpty().trim()
    }

    private fun sameText(a: String, b: String): Boolean =
        a.trim().equals(b.trim(), ignoreCase = true)

    private fun looksLikeMessage(n: Notification, title: String, body: String): Boolean {
        if (n.category == Notification.CATEGORY_MESSAGE) return true
        if (n.extras?.getParcelableArray(Notification.EXTRA_MESSAGES)?.isNotEmpty() == true) return true

        val combined = "$title $body".lowercase()
        val hints = listOf(
            "zpráv", "poslal", "poslala", "napsal", "napsala",
            "message", "sent you", "new message", "dm", "chat"
        )
        return hints.any { combined.contains(it) }
    }

    companion object {
        const val ACTION_NEW_MESSAGE = "cz.radek.tiktokhlidac.NEW_MESSAGE"
    }
}
