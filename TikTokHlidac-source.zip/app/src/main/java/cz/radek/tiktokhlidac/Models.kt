package cz.radek.tiktokhlidac

data class TikTokAccount(
    val id: Long,
    val label: String,
    val matchText: String
)

data class TikTokMessage(
    val id: Long,
    val accountId: Long?,
    val accountLabel: String?,
    val title: String,
    val body: String,
    val postedAt: Long,
    val isRead: Boolean
)
