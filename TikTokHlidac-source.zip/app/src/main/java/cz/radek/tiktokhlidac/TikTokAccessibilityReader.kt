package cz.radek.tiktokhlidac

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.security.MessageDigest

/**
 * Volitelný režim čtení textu přímo z obrazovky TikToku.
 * Uživatel jej musí ručně povolit v Nastavení > Usnadnění a poté v aplikaci
 * aktivovat časově omezené čtení. Služba je omezena jen na balíčky TikToku.
 */
class TikTokAccessibilityReader : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastSnapshotHash = ""
    private var lastSavedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg !in ALLOWED_PACKAGES) return

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val activeUntil = prefs.getLong("screenReaderActiveUntil", 0L)
        if (System.currentTimeMillis() > activeUntil) return

        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ captureVisibleText() }, 650L)
    }

    override fun onInterrupt() = Unit

    private fun captureVisibleText() {
        val root = rootInActiveWindow ?: return
        val lines = linkedSetOf<String>()
        collectText(root, lines)

        val cleaned = lines
            .map { it.trim() }
            .filter { it.length in 1..500 }
            .filterNot { isNoise(it) }
            .distinct()

        if (cleaned.size < 2) return

        val body = cleaned.joinToString("\n").take(7000)
        val digest = sha256(body)
        val now = System.currentTimeMillis()
        if (digest == lastSnapshotHash && now - lastSavedAt < 30_000L) return

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val accountIdRaw = prefs.getLong("screenReaderAccountId", Long.MIN_VALUE)
        val accountId = if (accountIdRaw == Long.MIN_VALUE) null else accountIdRaw

        val title = cleaned.firstOrNull { looksLikePersonOrChatTitle(it) }
            ?: cleaned.firstOrNull()
            ?: "TikTok chat"

        val key = "screen:$digest:${now / 60_000L}"
        DatabaseHelper(applicationContext).insertMessage(
            accountId = accountId,
            title = "[Obrazovka] $title",
            body = body,
            postedAt = now,
            notificationKey = key
        )

        lastSnapshotHash = digest
        lastSavedAt = now
        sendBroadcast(Intent(TikTokNotificationListener.ACTION_NEW_MESSAGE).setPackage(packageName))
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableSet<String>) {
        if (node == null) return
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }

    private fun isNoise(text: String): Boolean {
        val t = text.lowercase()
        val exact = setOf(
            "domů", "home", "objevit", "discover", "inbox", "doručená pošta",
            "profil", "profile", "hledat", "search", "sdílet", "share",
            "komentáře", "comments", "napsat zprávu", "message…", "message",
            "odeslat", "send", "zpět", "back"
        )
        return t in exact
    }

    private fun looksLikePersonOrChatTitle(text: String): Boolean {
        if (text.length > 80) return false
        if (text.contains("\n")) return false
        if (text.startsWith("@")) return true
        return text.count { it == ' ' } <= 4 && text.any { it.isLetter() }
    }

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }.take(24)
    }

    companion object {
        private val ALLOWED_PACKAGES = setOf(
            "com.zhiliaoapp.musically",
            "com.zhiliaoapp.musically.go"
        )
    }
}
