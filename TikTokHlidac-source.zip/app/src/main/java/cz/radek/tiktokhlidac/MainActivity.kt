package cz.radek.tiktokhlidac

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var db: DatabaseHelper
    private lateinit var accountSpinner: Spinner
    private lateinit var captureAccountSpinner: Spinner
    private lateinit var messageList: ListView
    private lateinit var statusText: TextView
    private lateinit var screenReaderStatusText: TextView
    private lateinit var onlyMessages: CheckBox
    private var accounts: List<TikTokAccount> = emptyList()
    private var filterAccountId: Long? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshMessages()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        setContentView(buildUi())
        refreshAll()
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(TikTokNotificationListener.ACTION_NEW_MESSAGE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    override fun onStop() {
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onStop()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.rgb(16, 16, 20))
        }

        root.addView(TextView(this).apply {
            text = "TikTok Hlídač 2"
            textSize = 26f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Zprávy z oznámení i přímo z obrazovky TikToku"
            textSize = 14f
            setTextColor(Color.rgb(180, 180, 190))
            setPadding(0, 2, 0, 12)
        })

        statusText = statusBox()
        root.addView(statusText, fullWidth())
        root.addView(Button(this).apply {
            text = "1. Povolit oznámení TikToku"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }, fullWidth())

        screenReaderStatusText = statusBox()
        root.addView(screenReaderStatusText, fullWidth())
        root.addView(Button(this).apply {
            text = "2. Povolit čtení z obrazovky"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, fullWidth())

        root.addView(TextView(this).apply {
            text = "Účet pro ukládání zpráv z obrazovky:"
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, 0)
        })
        captureAccountSpinner = Spinner(this)
        root.addView(captureAccountSpinner, fullWidth())

        val captureRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        captureRow.addView(Button(this).apply {
            text = "Číst z TikToku 10 min"
            setOnClickListener { startScreenReading() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        captureRow.addView(Button(this).apply {
            text = "STOP"
            setOnClickListener { stopScreenReading() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.4f))
        root.addView(captureRow, fullWidth())

        val accountRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        accountSpinner = Spinner(this)
        accountRow.addView(accountSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        accountRow.addView(Button(this).apply {
            text = "+ účet"
            setOnClickListener { showAddAccountDialog() }
        })
        root.addView(accountRow, fullWidth())

        onlyMessages = CheckBox(this).apply {
            text = "U oznámení ukládat jen pravděpodobné soukromé zprávy"
            setTextColor(Color.WHITE)
            isChecked = getSharedPreferences("settings", MODE_PRIVATE)
                .getBoolean("onlyLikelyMessages", true)
            setOnCheckedChangeListener { _, checked ->
                getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putBoolean("onlyLikelyMessages", checked).apply()
            }
        }
        root.addView(onlyMessages, fullWidth())

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(Button(this).apply {
            text = "Označit přečtené"
            setOnClickListener { db.markAllRead(); refreshMessages() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actionRow.addView(Button(this).apply {
            text = "Smazat historii"
            setOnClickListener { confirmClear() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actionRow, fullWidth())

        messageList = ListView(this).apply {
            dividerHeight = dp(8)
            setBackgroundColor(Color.TRANSPARENT)
            setOnItemClickListener { _, _, position, _ ->
                val item = adapter.getItem(position) as? TikTokMessage ?: return@setOnItemClickListener
                db.markMessageRead(item.id)
                showMessage(item)
                refreshMessages()
            }
        }
        root.addView(messageList, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        root.addView(TextView(this).apply {
            text = "Soukromí: data se ukládají jen v telefonu. Režim obrazovky je omezený na TikTok a spustíš ho ručně na 10 minut."
            textSize = 12f
            setTextColor(Color.rgb(155, 155, 166))
            setPadding(0, dp(8), 0, 0)
        })

        return root
    }

    private fun statusBox() = TextView(this).apply {
        textSize = 14f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(27, 27, 34))
    }

    private fun refreshAll() {
        refreshStatus()
        refreshAccounts()
        refreshMessages()
    }

    private fun refreshStatus() {
        val notificationEnabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        statusText.text = if (notificationEnabled) {
            "✅ Čtení oznámení je povolené"
        } else {
            "ℹ️ Oznámení nejsou povolená. Pro verzi z obrazovky nejsou nutná."
        }

        val accessibilityEnabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName, ignoreCase = true) == true
        val activeUntil = getSharedPreferences("settings", MODE_PRIVATE)
            .getLong("screenReaderActiveUntil", 0L)
        val active = System.currentTimeMillis() < activeUntil
        val untilText = if (active) {
            SimpleDateFormat("HH:mm", Locale("cs", "CZ")).format(Date(activeUntil))
        } else null

        screenReaderStatusText.text = when {
            !accessibilityEnabled -> "⚠️ Čtení z obrazovky není povolené"
            active -> "✅ Čtení z obrazovky je aktivní do $untilText"
            else -> "✅ Služba je povolená • čtení je teď vypnuté"
        }
    }

    private fun refreshAccounts() {
        accounts = db.getAccounts()

        val filterLabels = mutableListOf("Všechny účty")
        filterLabels += accounts.map { it.label }
        filterLabels += "Neurčeno"
        accountSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, filterLabels)
        accountSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                filterAccountId = when {
                    position == 0 -> null
                    position in 1..accounts.size -> accounts[position - 1].id
                    else -> Long.MIN_VALUE
                }
                refreshMessages()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }

        val captureLabels = mutableListOf("Neurčeno")
        captureLabels += accounts.map { it.label }
        captureAccountSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, captureLabels)
        val savedId = getSharedPreferences("settings", MODE_PRIVATE)
            .getLong("screenReaderAccountId", Long.MIN_VALUE)
        val savedIndex = accounts.indexOfFirst { it.id == savedId }
        captureAccountSpinner.setSelection(if (savedIndex >= 0) savedIndex + 1 else 0)
        captureAccountSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedId = if (position == 0) Long.MIN_VALUE else accounts[position - 1].id
                getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putLong("screenReaderAccountId", selectedId).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
    }

    private fun refreshMessages() {
        if (!::messageList.isInitialized) return
        val raw = if (filterAccountId == Long.MIN_VALUE) {
            db.getMessages(null).filter { it.accountId == null }
        } else {
            db.getMessages(filterAccountId)
        }
        messageList.adapter = MessageAdapter(this, raw)
    }

    private fun startScreenReading() {
        val accessibilityEnabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName, ignoreCase = true) == true
        if (!accessibilityEnabled) {
            Toast.makeText(this, "Nejdřív povol TikTok Hlídač v Usnadnění.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val until = System.currentTimeMillis() + 10 * 60 * 1000L
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putLong("screenReaderActiveUntil", until)
            .apply()
        refreshStatus()
        Toast.makeText(this, "Čtení zapnuto na 10 minut. Otevři teď chat v TikToku.", Toast.LENGTH_LONG).show()

        val launch = packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
            ?: packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically.go")
        if (launch != null) startActivity(launch)
    }

    private fun stopScreenReading() {
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putLong("screenReaderActiveUntil", 0L)
            .apply()
        refreshStatus()
        Toast.makeText(this, "Čtení z obrazovky vypnuto.", Toast.LENGTH_SHORT).show()
    }

    private fun showAddAccountDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
        }
        val labelInput = EditText(this).apply {
            hint = "Název účtu, např. @kralkolarka"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val matchInput = EditText(this).apply {
            hint = "Rozpoznávací text pro oznámení (volitelné)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        box.addView(labelInput)
        box.addView(matchInput)

        AlertDialog.Builder(this)
            .setTitle("Přidat TikTok účet")
            .setView(box)
            .setPositiveButton("Přidat") { _, _ ->
                val label = labelInput.text.toString().trim()
                if (label.isNotBlank()) {
                    db.addAccount(label, matchInput.text.toString().trim())
                    refreshAccounts()
                    refreshMessages()
                }
            }
            .setNegativeButton("Zrušit", null)
            .show()
    }

    private fun showMessage(item: TikTokMessage) {
        val whenText = SimpleDateFormat("d. M. yyyy HH:mm", Locale("cs", "CZ"))
            .format(Date(item.postedAt))
        val messageText = item.body.ifBlank { "Bez textu." }
        AlertDialog.Builder(this)
            .setTitle(item.title.ifBlank { "TikTok zpráva" })
            .setMessage("Účet: ${item.accountLabel ?: "Neurčeno"}\nČas: $whenText\n\n$messageText")
            .setPositiveButton("Zavřít", null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Smazat historii?")
            .setMessage("Smažou se jen uložené záznamy v TikTok Hlídači, ne zprávy v TikToku.")
            .setPositiveButton("Smazat") { _, _ -> db.clearMessages(); refreshMessages() }
            .setNegativeButton("Ne", null)
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private class MessageAdapter(context: Context, private val items: List<TikTokMessage>) : ArrayAdapter<TikTokMessage>(context, android.R.layout.simple_list_item_1, items) {
        private val dateFormat = SimpleDateFormat("d. M. HH:mm", Locale("cs", "CZ"))

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val box = (convertView as? LinearLayout) ?: LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(Color.rgb(27, 27, 34))
                addView(TextView(context).apply { id = 1; textSize = 16f; setTextColor(Color.WHITE) })
                addView(TextView(context).apply { id = 2; textSize = 14f; setTextColor(Color.rgb(225, 225, 230)) })
                addView(TextView(context).apply { id = 3; textSize = 12f; setTextColor(Color.rgb(155, 155, 166)) })
            }
            val item = items[position]
            box.findViewById<TextView>(1).text = "${if (item.isRead) "" else "● NOVÁ  "}${item.accountLabel ?: "Neurčeno"}"
            box.findViewById<TextView>(2).text = buildString {
                append(item.title.ifBlank { "TikTok" })
                append("\n")
                append(item.body.ifBlank { "(bez textu)" }.take(500))
            }
            box.findViewById<TextView>(3).text = "${dateFormat.format(Date(item.postedAt))} • klepni pro celý text"
            return box
        }

        private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
    }
}
