package cz.radek.tiktokhlidac

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "tiktok_hlidac.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                match_text TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER,
                title TEXT NOT NULL DEFAULT '',
                body TEXT NOT NULL DEFAULT '',
                posted_at INTEGER NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0,
                notification_key TEXT NOT NULL UNIQUE,
                FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE SET NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun addAccount(label: String, matchText: String): Long {
        val values = ContentValues().apply {
            put("label", label.trim())
            put("match_text", matchText.trim())
        }
        return writableDatabase.insert("accounts", null, values)
    }

    fun deleteAccount(id: Long) {
        writableDatabase.delete("accounts", "id = ?", arrayOf(id.toString()))
    }

    fun getAccounts(): List<TikTokAccount> {
        val result = mutableListOf<TikTokAccount>()
        readableDatabase.rawQuery("SELECT id, label, match_text FROM accounts ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                result += TikTokAccount(c.getLong(0), c.getString(1), c.getString(2))
            }
        }
        return result
    }

    fun matchAccount(text: String): Long? {
        val accounts = getAccounts()
        if (accounts.isEmpty()) return null
        val normalized = text.lowercase()
        accounts.firstOrNull { a ->
            a.matchText.isNotBlank() && normalized.contains(a.matchText.lowercase())
        }?.let { return it.id }
        return if (accounts.size == 1) accounts.first().id else null
    }

    fun insertMessage(
        accountId: Long?,
        title: String,
        body: String,
        postedAt: Long,
        notificationKey: String
    ) {
        val values = ContentValues().apply {
            if (accountId == null) putNull("account_id") else put("account_id", accountId)
            put("title", title)
            put("body", body)
            put("posted_at", postedAt)
            put("is_read", 0)
            put("notification_key", notificationKey)
        }
        writableDatabase.insertWithOnConflict(
            "messages", null, values, SQLiteDatabase.CONFLICT_IGNORE
        )
    }

    fun getMessages(accountId: Long?): List<TikTokMessage> {
        val result = mutableListOf<TikTokMessage>()
        val where = if (accountId == null) "" else "WHERE m.account_id = ?"
        val args = if (accountId == null) null else arrayOf(accountId.toString())
        val sql = """
            SELECT m.id, m.account_id, a.label, m.title, m.body, m.posted_at, m.is_read
            FROM messages m
            LEFT JOIN accounts a ON a.id = m.account_id
            $where
            ORDER BY m.posted_at DESC
            LIMIT 500
        """.trimIndent()
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) {
                result += TikTokMessage(
                    id = c.getLong(0),
                    accountId = if (c.isNull(1)) null else c.getLong(1),
                    accountLabel = if (c.isNull(2)) null else c.getString(2),
                    title = c.getString(3),
                    body = c.getString(4),
                    postedAt = c.getLong(5),
                    isRead = c.getInt(6) != 0
                )
            }
        }
        return result
    }

    fun markMessageRead(id: Long) {
        val values = ContentValues().apply { put("is_read", 1) }
        writableDatabase.update("messages", values, "id = ?", arrayOf(id.toString()))
    }

    fun markAllRead() {
        writableDatabase.execSQL("UPDATE messages SET is_read = 1")
    }

    fun clearMessages() {
        writableDatabase.delete("messages", null, null)
    }
}
