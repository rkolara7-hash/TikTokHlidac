# TikTok Hlídač 2

Android aplikace pro lokální ukládání TikTok oznámení a, po ručním povolení služby Usnadnění, textu viditelného na obrazovce TikToku.

Data se ukládají pouze lokálně v telefonu.
